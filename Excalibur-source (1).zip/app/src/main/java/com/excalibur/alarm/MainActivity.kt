package com.excalibur.alarm

import android.app.*
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import java.time.LocalDate
import java.util.Calendar

class MainActivity:Activity() {
    private var dark=true
    private lateinit var list:LinearLayout
    private lateinit var root:LinearLayout
    private val dayNames=listOf("ی","د","س","چ","پ","ج","ش")
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
        if(android.os.Build.VERSION.SDK_INT>=33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS),12)
        build()
    }
    private fun build() {
        root=LinearLayout(this).apply{orientation=1;setPadding(18,18,18,18);setBackgroundColor(if(dark) Color.rgb(20,23,34) else Color.rgb(246,247,251))}
        val fg=if(dark) Color.WHITE else Color.rgb(30,35,50)
        root.addView(TextView(this).apply{text="⚔  Excalibur";textSize=30f;setTextColor(fg);gravity=Gravity.CENTER;setPadding(0,12,0,8)})
        root.addView(TextView(this).apply{text="آلارم هوشمند با تقویم شمسی  •  ${Jalali.format(LocalDate.now())}";textSize=15f;setTextColor(fg);gravity=Gravity.CENTER})
        val bar=LinearLayout(this).apply{gravity=Gravity.CENTER}
        bar.addView(Button(this).apply{text="＋ آلارم جدید";setOnClickListener{edit(null)}})
        bar.addView(Button(this).apply{text="ذخیره الگو";setOnClickListener{savePattern()}})
        bar.addView(Button(this).apply{text="الگوها";setOnClickListener{restorePattern()}})
        bar.addView(Button(this).apply{text=if(dark)"☀" else "☾";setOnClickListener{dark=!dark;build()}})
        root.addView(bar)
        root.addView(TextView(this).apply{text="آلارم‌های من";textSize=20f;setTextColor(fg);setPadding(4,18,4,8)})
        list=LinearLayout(this).apply{orientation=1}
        val scroll=ScrollView(this);scroll.addView(list);root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); render()
    }
    private fun render() {
        list.removeAllViews()
        Store.get(this).sortedWith(compareBy<AlarmItem>{it.hour}.thenBy{it.minute}).forEach { a ->
            val row=LinearLayout(this).apply{orientation=1;setPadding(14,12,14,12);setBackgroundColor(if(dark) Color.rgb(39,44,61) else Color.WHITE)}
            row.addView(TextView(this).apply{text=String.format("%02d:%02d",a.hour,a.minute);textSize=30f;setTextColor(if(dark) Color.WHITE else Color.BLACK)})
            row.addView(TextView(this).apply{text="${a.label}  •  ${repeatText(a)}";textSize=14f;setTextColor(if(dark) Color.LTGRAY else Color.DKGRAY)})
            val actions=LinearLayout(this)
            actions.addView(Button(this).apply{text=if(a.enabled)"روشن" else "خاموش";setOnClickListener{
                a.enabled=!a.enabled;replace(a);if(a.enabled)AlarmScheduler.schedule(this@MainActivity,a) else AlarmScheduler.cancel(this@MainActivity,a.id);render()
            }})
            actions.addView(Button(this).apply{text="ویرایش";setOnClickListener{edit(a)}})
            actions.addView(Button(this).apply{text="حذف";setOnClickListener{AlarmScheduler.cancel(this@MainActivity,a.id);Store.save(this@MainActivity,Store.get(this@MainActivity).filterNot{it.id==a.id});render()}})
            row.addView(actions);list.addView(row);list.addView(View(this).apply{setBackgroundColor(Color.GRAY);layoutParams=LinearLayout.LayoutParams(-1,1)})
        }
        if(Store.get(this).isEmpty()) list.addView(TextView(this).apply{text="هنوز آلارمی نساخته‌اید.";textSize=16f;setTextColor(if(dark)Color.WHITE else Color.BLACK);gravity=Gravity.CENTER;setPadding(32,32,32,32)})
    }
    private fun repeatText(a:AlarmItem):String = when { a.date.isNotBlank()->"تاریخ ${runCatching{Jalali.format(LocalDate.parse(a.date))}.getOrDefault(a.date)}"; a.days.isEmpty()->"یک‌بار"; else->"تکرار هفتگی" }
    private fun replace(a:AlarmItem) { Store.save(this,Store.get(this).map{if(it.id==a.id)a else it}) }
    private fun edit(old:AlarmItem?) {
        val cal=Calendar.getInstance()
        val time=TimePickerDialog(this,{_,h,m->
            val name=EditText(this).apply{hint="عنوان آلارم";setText(old?.label ?: "آلارم")}
            val checks=LinearLayout(this).apply{orientation=1}
            val selected=BooleanArray(7){old?.days?.contains(it) ?: false}
            val labels=listOf("یکشنبه","دوشنبه","سه‌شنبه","چهارشنبه","پنجشنبه","جمعه","شنبه")
            val boxes=labels.mapIndexed{idx,s->CheckBox(this).apply{text=s;isChecked=selected[idx];setTextColor(if(dark)Color.WHITE else Color.BLACK);setOnCheckedChangeListener{_,v->selected[idx]=v}}}
            boxes.forEach{checks.addView(it)}
            val dateBtn=Button(this).apply{text=if(old?.date?.isNotBlank()==true)"تاریخ انتخاب شده" else "انتخاب تاریخ شمسی (اختیاری)"}
            var chosenDate=old?.date ?: ""
            dateBtn.setOnClickListener {
                val today=Calendar.getInstance()
                DatePickerDialog(this,{_,y,mo,d->
                    val ld=LocalDate.of(y,mo+1,d);chosenDate=ld.toString();dateBtn.text="تاریخ: ${Jalali.format(ld)}"
                    boxes.forEach{it.isChecked=false}
                },today.get(Calendar.YEAR),today.get(Calendar.MONTH),today.get(Calendar.DAY_OF_MONTH)).show()
            }
            val layout=LinearLayout(this).apply{orientation=1;setPadding(24,8,24,8);addView(name);addView(TextView(this).apply{text="روزهای تکرار (خالی = یک‌بار)";setTextColor(if(dark)Color.WHITE else Color.BLACK)});addView(checks);addView(dateBtn)}
            AlertDialog.Builder(this).setTitle("تنظیم آلارم").setView(layout).setPositiveButton("ذخیره"){_,_->
                val a=old ?: AlarmItem(Store.nextId(this),h,m,"")
                a.hour=h;a.minute=m;a.label=name.text.toString().ifBlank{"آلارم"};a.days=selected.indices.filter{selected[it]}.toSet();a.date=chosenDate;a.enabled=true
                val all=Store.get(this);if(old==null)all.add(a) else {val ix=all.indexOfFirst{it.id==a.id};if(ix>=0)all[ix]=a}
                Store.save(this,all);AlarmScheduler.schedule(this,a);render()
            }.setNegativeButton("انصراف",null).show()
        },old?.hour ?: cal.get(Calendar.HOUR_OF_DAY),old?.minute ?: cal.get(Calendar.MINUTE),true)
        time.show()
    }

    private fun restorePattern() {
        val prefs=getSharedPreferences("excalibur_patterns",0)
        val count=prefs.getInt("count",0)
        if(count==0){Toast.makeText(this,"هنوز الگویی ذخیره نشده",Toast.LENGTH_SHORT).show();return}
        val names=(1..count).map{"الگوی شماره $it"}
        AlertDialog.Builder(this).setTitle("انتخاب الگو").setItems(names.toTypedArray()){_,which->
            val raw=prefs.getString("pattern_${which+1}","[]") ?: "[]"
            val arr=org.json.JSONArray(raw)
            val restored=(0 until arr.length()).map{AlarmItem.parse(arr.getJSONObject(it))}
            Store.get(this).forEach{AlarmScheduler.cancel(this,it.id)}
            Store.save(this,restored)
            restored.forEach{if(it.enabled)AlarmScheduler.schedule(this,it)}
            render()
            Toast.makeText(this,"الگو اعمال شد",Toast.LENGTH_SHORT).show()
        }.setNegativeButton("انصراف",null).show()
    }
    private fun savePattern() {
        val a=Store.get(this)
        if(a.isEmpty()){Toast.makeText(this,"ابتدا یک آلارم بسازید",Toast.LENGTH_SHORT).show();return}
        val prefs=getSharedPreferences("excalibur_patterns",0)
        val count=prefs.getInt("count",0)+1
        val json=org.json.JSONArray();a.forEach{json.put(it.json())}
        prefs.edit().putInt("count",count).putString("pattern_$count",json.toString()).apply()
        Toast.makeText(this,"الگوی برنامه ذخیره شد",Toast.LENGTH_SHORT).show()
    }
}
