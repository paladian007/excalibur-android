package com.excalibur.alarm

import android.app.Activity
import android.os.Bundle
import android.media.Ringtone
import android.media.RingtoneManager
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AlarmRingActivity:Activity() {
    private var ringtone:Ringtone?=null
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        ringtone=RingtoneManager.getRingtone(this,RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM))
        ringtone?.play()
        val box=LinearLayout(this).apply{orientation=1;gravity=Gravity.CENTER;setPadding(32,32,32,32)}
        box.addView(TextView(this).apply{text="Excalibur";textSize=30f;gravity=Gravity.CENTER})
        box.addView(TextView(this).apply{text=intent.getStringExtra("label") ?: "زمان آلارم";textSize=24f;gravity=Gravity.CENTER})
        box.addView(Button(this).apply{text="خاموش کردن";setOnClickListener{ringtone?.stop();finish()}})
        box.addView(Button(this).apply{text="تعویق ۵ دقیقه";setOnClickListener{
            ringtone?.stop()
            val a=AlarmItem(900000+System.currentTimeMillis().toInt(),java.time.LocalTime.now().plusMinutes(5).hour,
                java.time.LocalTime.now().plusMinutes(5).minute,"تعویق آلارم")
            val all=Store.get(this@AlarmRingActivity)
            all.add(a); Store.save(this@AlarmRingActivity,all)
            AlarmScheduler.schedule(this@AlarmRingActivity,a); finish()
        }})
        setContentView(box)
    }
    override fun onDestroy(){ringtone?.stop();super.onDestroy()}
}
