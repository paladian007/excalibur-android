package com.excalibur.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import java.time.*

object AlarmScheduler {
    fun scheduleAll(c:Context) { Store.get(c).forEach { if(it.enabled) schedule(c,it) else cancel(c,it.id) } }
    fun schedule(c:Context,a:AlarmItem) {
        val am=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val now=ZonedDateTime.now()
        var target:ZonedDateTime?=null
        if(a.date.isNotBlank()) {
            runCatching {
                val d=LocalDate.parse(a.date)
                var t=d.atTime(a.hour,a.minute).atZone(ZoneId.systemDefault())
                if(t.isAfter(now)) target=t
            }
        } else if(a.days.isEmpty()) {
            var t=now.toLocalDate().atTime(a.hour,a.minute).atZone(ZoneId.systemDefault())
            if(!t.isAfter(now)) t=t.plusDays(1)
            target=t
        } else {
            for(i in 0..7) {
                val d=now.toLocalDate().plusDays(i.toLong())
                val dow=d.dayOfWeek.value % 7
                if(dow in a.days) {
                    val t=d.atTime(a.hour,a.minute).atZone(ZoneId.systemDefault())
                    if(t.isAfter(now)) { target=t; break }
                }
            }
        }
        target?.let {
            val pi=pending(c,a.id)
            if(android.os.Build.VERSION.SDK_INT>=31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,it.toInstant().toEpochMilli(),pi)
            } else am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,it.toInstant().toEpochMilli(),pi)
        }
    }
    fun cancel(c:Context,id:Int) {
        val am=c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pending(c,id))
    }
    private fun pending(c:Context,id:Int):PendingIntent {
        val i=Intent(c,AlarmReceiver::class.java).putExtra("id",id)
        return PendingIntent.getBroadcast(c,id,i,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
