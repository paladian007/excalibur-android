package com.excalibur.alarm

import java.time.LocalDate

object Jalali {
    fun fromGregorian(date: LocalDate): Triple<Int, Int, Int> {
        val gy = date.year; val gm = date.monthValue; val gd = date.dayOfMonth
        val gdm = intArrayOf(0,31, if (leap(gy)) 29 else 28,31,30,31,30,31,31,30,31,30,31)
        var gy2 = gy - 1600; var gm2 = gm - 1; val gd2 = gd - 1
        var days = 365*gy2 + (gy2+3)/4 - (gy2+99)/100 + (gy2+399)/400
        for (i in 0 until gm2) days += gdm[i+1]
        days += gd2
        var jdays = days - 79
        val jnp = jdays / 12053; jdays %= 12053
        var jy = 979 + 33*jnp + 4*(jdays/1461); jdays %= 1461
        if (jdays >= 366) { jy += (jdays-1)/365; jdays = (jdays-1)%365 }
        val jm: Int; val jd: Int
        if (jdays < 186) { jm = 1 + (jdays/31).toInt(); jd = 1 + (jdays%31).toInt() }
        else { jm = 7 + ((jdays-186)/30).toInt(); jd = 1 + ((jdays-186)%30).toInt() }
        return Triple(jy,jm,jd)
    }
    private fun leap(y:Int) = y%4==0 && (y%100!=0 || y%400==0)
    fun format(date: LocalDate): String {
        val (y,m,d)=fromGregorian(date)
        val months=listOf("فروردین","اردیبهشت","خرداد","تیر","مرداد","شهریور","مهر","آبان","آذر","دی","بهمن","اسفند")
        return "$d ${months[m-1]} $y"
    }
}
