package com.excalibur.alarm

import android.app.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

class AlarmReceiver:BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) {
        val id=intent.getIntExtra("id",-1)
        val alarm=Store.get(context).firstOrNull{it.id==id} ?: return
        val show=Intent(context,AlarmRingActivity::class.java)
            .putExtra("label",alarm.label)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val full=PendingIntent.getActivity(context,id,show,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val channel="excalibur_alarm"
        if(Build.VERSION.SDK_INT>=26) {
            manager.createNotificationChannel(NotificationChannel(channel,"آلارم Excalibur",NotificationManager.IMPORTANCE_HIGH).apply {
                description="اعلان زنگ‌های برنامه"
                lockscreenVisibility=Notification.VISIBILITY_PUBLIC
            })
        }
        val notification=Notification.Builder(context,channel)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Excalibur")
            .setContentText(alarm.label)
            .setCategory(Notification.CATEGORY_ALARM)
            .setPriority(Notification.PRIORITY_MAX)
            .setAutoCancel(true)
            .setFullScreenIntent(full,true)
            .setContentIntent(full)
            .build()
        manager.notify(id,notification)
        if(alarm.enabled && (alarm.days.isNotEmpty() || alarm.date.isBlank())) AlarmScheduler.schedule(context,alarm)
        else { alarm.enabled=false; Store.save(context,Store.get(context).map{if(it.id==id) alarm else it}) }
    }
}
class BootReceiver:BroadcastReceiver() {
    override fun onReceive(context:Context,intent:Intent) { if(intent.action==Intent.ACTION_BOOT_COMPLETED) AlarmScheduler.scheduleAll(context) }
}
