package com.excalibur.alarm

import org.json.JSONArray
import org.json.JSONObject

data class AlarmItem(val id:Int, var hour:Int, var minute:Int, var label:String, var enabled:Boolean=true,
                     var days:Set<Int> = emptySet(), var date:String = "") {
    fun json()=JSONObject().put("id",id).put("hour",hour).put("minute",minute).put("label",label)
        .put("enabled",enabled).put("days",JSONArray(days.toList())).put("date",date)
    companion object {
        fun parse(o:JSONObject):AlarmItem {
            val a=o.optJSONArray("days") ?: JSONArray()
            val ds=(0 until a.length()).map{a.getInt(it)}.toSet()
            return AlarmItem(o.getInt("id"),o.getInt("hour"),o.getInt("minute"),o.optString("label","آلارم"),
                o.optBoolean("enabled",true),ds,o.optString("date",""))
        }
    }
}
object Store {
    private const val PREF="excalibur_data"
    fun get(c:android.content.Context):MutableList<AlarmItem> {
        val raw=c.getSharedPreferences(PREF,0).getString("alarms","[]") ?: "[]"
        val a=JSONArray(raw); return (0 until a.length()).map{AlarmItem.parse(a.getJSONObject(it))}.toMutableList()
    }
    fun save(c:android.content.Context, items:List<AlarmItem>) {
        val a=JSONArray(); items.forEach{a.put(it.json())}
        c.getSharedPreferences(PREF,0).edit().putString("alarms",a.toString()).apply()
    }
    fun nextId(c:android.content.Context)=get(c).maxOfOrNull{it.id}?.plus(1) ?: 1
}
